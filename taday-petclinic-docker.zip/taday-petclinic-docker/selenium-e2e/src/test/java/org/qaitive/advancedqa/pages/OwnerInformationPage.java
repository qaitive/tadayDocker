package org.qaitive.advancedqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static org.qaitive.advancedqa.driver.MyDriver.getDriver;

public class OwnerInformationPage extends PageFactory {


    public OwnerInformationPage() {
        PageFactory.initElements(getDriver(), this);
    }

    public boolean verifyOwnerLastName(String lastName) {
        List<WebElement> elements = getDriver().findElements(By.xpath("//table//td"));

        return elements.get(0).getText().contains(lastName);
    }
}