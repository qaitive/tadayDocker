package org.qaitive.advancedqa.tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.qaitive.advancedqa.pages.LandingPage;

/**
 * Unit test for simple App.
 */
public class AppTest extends BaseTest {

    @Test
    public void shouldOpenLandingPage() {
        assertTrue(new LandingPage().openPage().isPageOpen());
    }

    @Test
    public void shouldVerifyOwnerSearch() {
        String expectedLastName = "Black";
        assertTrue(new LandingPage().openPage().openFindOwner().findOwner(expectedLastName)
                .verifyOwnerLastName(expectedLastName));
    }

}
