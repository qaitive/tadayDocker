package org.qaitive.advancedqa.utils;

public class Veterinarian {

    private String firstName;
    private String lastName;

    private Veterinarian() { }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Veterinarian(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "First name: " + firstName + " Last name: " + lastName;
    }

    public static class Builder {
        private String firstName;
        private String lastName;

        public Builder firstName(String firstName) {
            this.firstName = firstName;

            return this;
        }

        public Builder lastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Veterinarian build() {
            return new Veterinarian(this.firstName, this.lastName);
        }


    }
}
