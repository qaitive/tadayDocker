package org.qaitive.advancedqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.logging.Logger;

import static org.qaitive.advancedqa.driver.MyDriver.*;

public class LandingPage extends PageFactory {

    public LandingPage() {
        PageFactory.initElements(getDriver(), this);

    }

    public LandingPage openPage() {
//         String baseUrl = System.getenv("APP_URL");
//         String port = System.getenv("APP_URL");

        getDriver().navigate().to("http://" + BASE_URL + ":" + BASE_PORT);

//        this.driver.navigate().to("http://petclinic:8080");

        return this;
    }

    public boolean isPageOpen() {
        WebDriverWait wait = new WebDriverWait(getDriver(), 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("main-navbar")));

        Logger.getAnonymousLogger().info("TITLE: " + getDriver().getTitle());

        WebElement mainNavbar = getDriver().findElement(By.id("main-navbar"));

        return mainNavbar.isDisplayed() && mainNavbar.isEnabled();
    }

    public FindOwner openFindOwner() {
        WebDriverWait wait = new WebDriverWait(getDriver(), 10);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@title='find owners']/span[2]"))).click();

        return new FindOwner();
    }

}
