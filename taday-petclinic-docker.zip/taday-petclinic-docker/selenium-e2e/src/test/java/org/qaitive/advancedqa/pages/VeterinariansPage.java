package org.qaitive.advancedqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.qaitive.advancedqa.utils.Veterinarian;

import java.net.MalformedURLException;
import java.util.List;
import java.util.stream.Collectors;

import static org.qaitive.advancedqa.driver.MyDriver.*;

public class VeterinariansPage extends PageFactory {

    @FindBy(id="vets")
    private WebElement vetsTable;


    public static void open(){
        getDriver().navigate().to("http://" + BASE_URL + ":" + BASE_PORT + "/vets.html");
    }

    public VeterinariansPage() {
        initElements(getDriver(), this);
    }

    public List<Veterinarian> getAllVeterinarians() {
        return vetsTable.findElements(By.cssSelector("td:first-child"))
                .stream()
                .map(element -> {
                    String[] fullName = element.getText().split(" ");
                    return new Veterinarian(fullName[0], fullName[1]);
                })
                .collect(Collectors.toList());
    }
}
