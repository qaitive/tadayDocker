package org.qaitive.advancedqa.database;

import org.qaitive.advancedqa.utils.Veterinarian;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class DbUtils {

    public static List<Veterinarian> selectVeterinariansFromDb(String sql)  {
        DatabaseConnection connection = new DatabaseConnection();
        try (Connection conn = connection.getConnection()) {
            Statement st = conn.createStatement();
            List<Veterinarian> array = new ArrayList<>();
            ResultSet resultSet = st.executeQuery(sql);
            while (resultSet.next()) {
                array.add(new Veterinarian(resultSet.getString("first_name"), resultSet.getString("last_name")));
            }

            return array;
        } catch (SQLException e) {
            Logger.getAnonymousLogger().info(e.getMessage());
            throw new RuntimeException(e.getMessage());
        }

    }

    public static boolean execute(String sql)  {
        DatabaseConnection connection = new DatabaseConnection();
        try (Connection conn = connection.getConnection()) {
            Statement st;
            st = conn.createStatement();

            return st.execute(sql);
        } catch (SQLException e) {
            Logger.getAnonymousLogger().info(e.getMessage());
            throw new RuntimeException(e.getMessage());
        }

    }



}
