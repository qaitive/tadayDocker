package org.qaitive.advancedqa.tests;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.qaitive.advancedqa.database.DbUtils;
import org.qaitive.advancedqa.pages.VeterinariansPage;
import org.qaitive.advancedqa.utils.Veterinarian;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class ParametrizedTestsJunit extends BaseTest {

    @Test
    void testVerifyVeterinarian() {
        Veterinarian sharonJenkins = new Veterinarian("Sharon", "Jenkins");

        String sql = "insert into vets (first_name, last_name) values ('Sharon', 'Jenkins');";
        DbUtils.execute(sql);
        sql = "select * from vets;";
        List<Veterinarian> veterinarians = DbUtils.selectVeterinariansFromDb(sql);


        assertThat(veterinarians.stream().map(Veterinarian::toString))
                .contains(sharonJenkins.toString());

        VeterinariansPage.open();
        VeterinariansPage veterinariansPage = new VeterinariansPage();

        assertThat(veterinariansPage.getAllVeterinarians().stream().map(Veterinarian::toString))
                .contains(sharonJenkins.toString());
    }

    @ParameterizedTest
    @ValueSource(strings = {"Adam Johnson", "Peter Jenkins", "Luise Whitaker"})
    void testVerifyVeterinarianValueSource(String fullName) {
        String[] name = fullName.split(" ");
        Veterinarian expectedVet = new Veterinarian(name[0], name[1]);

        String sql = String.format("insert into vets (first_name, last_name) values ('%s', '%s');", name[0], name[1]);
        DbUtils.execute(sql);

        sql = "select * from vets;";
        List<Veterinarian> veterinarians = DbUtils.selectVeterinariansFromDb(sql);


        assertThat(veterinarians.stream().map(Veterinarian::toString))
                .contains(expectedVet.toString());

        VeterinariansPage.open();
        VeterinariansPage veterinariansPage = new VeterinariansPage();

        assertThat(veterinariansPage.getAllVeterinarians().stream().map(Veterinarian::toString))
                .contains(expectedVet.toString());
    }



}
