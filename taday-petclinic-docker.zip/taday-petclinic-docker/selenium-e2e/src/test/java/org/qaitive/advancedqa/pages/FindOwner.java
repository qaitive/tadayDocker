package org.qaitive.advancedqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import static org.qaitive.advancedqa.driver.MyDriver.getDriver;

public class FindOwner extends PageFactory {


    public FindOwner() {
        PageFactory.initElements( getDriver(), this);
    }
    
    public OwnerInformationPage findOwner(String lastName) {
        getDriver().findElement(By.id("lastName")).sendKeys(lastName);
        getDriver().findElement(By.xpath("//*[@type='submit']")).click();

        return new OwnerInformationPage();
    }



}