package org.qaitive.advancedqa.tests;

import org.junit.jupiter.api.Test;
import org.qaitive.advancedqa.utils.CSVReader;

import java.io.FileNotFoundException;
import java.util.List;

public class TestingCSV {

    @Test
    public void testReadingCSV() throws FileNotFoundException {
        CSVReader csvReader = new CSVReader();
        List<List<String>> lines = csvReader.readCsvFile(this.getClass().getClassLoader().getResource("files/countries.csv").getPath());

        for (List<String> line : lines) {
            for (String val : line) {
//                Logger.getAnonymousLogger().info(val);
                System.out.print(val);
                System.out.print(" ");
            }
            System.out.println();
        }
    }
}
