package org.qaitive.advancedqa.tests;

import org.junit.jupiter.api.AfterEach;

import static org.qaitive.advancedqa.driver.MyDriver.quitDriver;

public class BaseTest {

    @AfterEach
    public void tearDown() {
        quitDriver();
    }

}
