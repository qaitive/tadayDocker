package org.qaitive.advancedqa.tests;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.qaitive.advancedqa.database.DatabaseConnection;
import org.qaitive.advancedqa.utils.Veterinarian;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class TestingWithDB {

    @Test
    void tesVerifyVeterinarian() throws SQLException {
        Veterinarian sharonJenkins = new Veterinarian("Sharon", "Jenkins");
        DatabaseConnection connection = new DatabaseConnection();
        Connection conn = connection.getConnection();
        Statement st = conn.createStatement();

        String sql = "select * from vets;";

        ResultSet resultSet = st.executeQuery(sql);

        List<Veterinarian> veterinarians = new ArrayList<>();

        while (resultSet.next()) {
            veterinarians.add(
                new Veterinarian.Builder()
                    .firstName(resultSet.getString("first_name"))
                    .lastName(resultSet.getString("last_name"))
                    .build()

//                new Veterinarian(resultSet.getString("first_name"), resultSet.getString("last_name"));
            );
        }

        veterinarians.forEach(vet -> Logger.getAnonymousLogger().info(vet.toString()));


        Assertions.assertThat(veterinarians).extracting(Veterinarian::getFirstName)
            .contains(sharonJenkins.getFirstName());
        Assertions.assertThat(veterinarians).extracting(Veterinarian::getLastName)
            .contains(sharonJenkins.getLastName());

//        Assertions.assertThat(veterinarians.get(5)).isEqualToComparingFieldByField(sharonJenkins);
//
//        Assertions.assertThat(
//            veterinarians.stream().filter(vet -> vet.getFirstName().startsWith("H")).map(Veterinarian::toString)
//        ).contains(sharonJenkins.toString());

    }

    @Test
    void testAddNewVeterinarian() throws SQLException {
        DatabaseConnection connection = new DatabaseConnection();
        Connection conn = connection.getConnection();
        Statement st = conn.createStatement();

        String sql = "insert into vets (first_name, last_name) values ('Adam', 'Norris');";

        st.execute(sql);


        sql = "select * from vets;";

        ResultSet resultSet = st.executeQuery(sql);

        List<Veterinarian> veterinarians = new ArrayList<>();

        while (resultSet.next()) {
            veterinarians.add(
                new Veterinarian.Builder()
                    .firstName(resultSet.getString("first_name"))
                    .lastName(resultSet.getString("last_name"))
                    .build()
            );
        }

        conn.close();

        Assertions.assertThat(
            veterinarians.stream().map(Veterinarian::toString)
        ).contains(new Veterinarian("Adam", "Norris").toString());
    }
}
