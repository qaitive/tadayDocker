package org.qaitive.advancedqa.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URL;

public class MyDriver {
    public static final String BASE_URL = System.getenv("APP_URL");
    public static final String BASE_PORT = System.getenv("APP_PORT");
    private static final String hub = System.getenv("HUB_HOST");
    private static final String port = System.getenv("HUB_PORT");
    private static int n = 0;

    private static WebDriver driver;

    public static synchronized WebDriver getDriver() {

//         String hub = "localhost";
//         String port = "4444";




        if (driver == null) {
            DesiredCapabilities dc;
                dc = DesiredCapabilities.chrome();
            try {
                driver = new RemoteWebDriver(new URL("http://" + hub + ":" + port + "/wd/hub"), dc);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e.getMessage());
            }
        }

//        if (driver ==null) {
//            System.setProperty("webdriver.chrome.driver", ClassLoader.getSystemClassLoader().getResource("driver/chromedriver.exe").getPath());
//            driver = new ChromeDriver();
//        }

        return driver;
    }

    public static void quitDriver() {
        driver.close();
        driver.quit();
        driver = null;
    }
}
