package org.qaitive.advancedqa.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Logger;

public class DatabaseConnection {
//    private static final String DB_URL = "localhost";
    private static final String DB_URL = "mysql";
    private static final String DB_PORT = "3306";
    private static final String DBMS = "mysql";
    private static final String DB = "petclinic";


    private final String userName = "veterinair";
    private final String password = "petclinic";


    public Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Connection conn = null;
        Properties connectionProps = new Properties();
        connectionProps.put("user", this.userName);
        connectionProps.put("password", this.password);

        conn = DriverManager.getConnection(
                "jdbc:" + DBMS + "://" + DB_URL + ":" + DB_PORT + "/" + DB,
                connectionProps);

        Logger.getAnonymousLogger().info("Connected to database");
        return conn;
    }

}
